const mongoose = require('mongoose');
const schema = mongoose.Schema;
require('./attendance');
require('./practiceSchedule');
require('./matchSchedule');

const playerSchema = new schema(
    {
        name : {
            type : String,
            required : true
        },
        email : {
            type : String,
            required: true
        },
        password : {
            type : String,
            required : true
        },
        gender : Boolean,
        game : [
            {
                gameType : String,
                playerRank : String,
                opponentRank : String
            }
        ],
        attendance : [
            {
                type : schema.Types.ObjectId,
                ref : 'Attendance'
            }
        ],
        progressInPracticeSessions : {
            nPracticeSessions : Number,
            practiceSession : [
                {
                    type : schema.Types.ObjectId,
                    ref : 'PracticeSchedule'
                }
            ]
        },
        progressInMatchSessions : {
            nMatchSessions : Number,
            matchSession : [
                {
                    type : schema.Types.ObjectId,
                    ref : 'MatchSchedule'
                }
            ]
        },
        isPresent : {
            type : Boolean,
            default : false
        },
        firstLogin : {
            type : Boolean,
            default : true
        }

    }
);

module.exports = mongoose.model('Player', playerSchema);
