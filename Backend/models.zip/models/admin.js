const mongoose = require('mongoose');
const schema = mongoose.Schema;

const adminSchema = new schema(
    {
        name : String,
        email : String,
        password : String,
        isAvailable : Boolean
    }
);

module.exports = mongoose.model('Admin', adminSchema);
