const mongoose = require('mongoose');
const schema = mongoose.Schema;

const coachSchema = new schema(
    {
        name : String,
        email : String,
        password : String,
        isAvailable : Boolean
    }
);

module.exports = mongoose.model('Coach', coachSchema);
